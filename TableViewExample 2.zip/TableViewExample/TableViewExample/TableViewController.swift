//
//  TableViewController.swift
//  TableViewExample
//
//  Created by user on 15.03.21.
//

import UIKit

class TableViewController: UITableViewController {

    var model = Model()
    var postsURL = "https://api.pandascore.co/lol/champions?"
    let sort = "sort=name&per_page=100&page="
    let token = "&token=IMkUa0X-2n231_13d_T_muOA-XIWNYQ2Jd-W_mDMcDZHXMV558o"
    var pageNum = 1
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadData()
        
    }
    
    func loadData(){
        for _ in 0...1  {
            if let url = URL(string:self.combineURL(url1: postsURL, sort: sort, token: token, pagenum: pageNum)){
               
                    if let data = try? Data(contentsOf: url){
                        print(data)
                        if let json = try? JSONSerialization.jsonObject(with: data){
                            if let posts = json as? [[String: Any]]{
                                for post in posts {
                                    let tempPost = Post()
                                    tempPost.name = post["name"] as! String
                                    model.posts.append(tempPost)
                                    
                                }
                            }
                        }
                    }
                    pageNum += 1
                
                
            }
        }
        
        
        
    }
    
    func combineURL(url1:String, sort:String, token:String, pagenum:Int) -> String{
        var url:String
        
        url = url1+sort+String(pagenum)+token
        
        
        return url
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return model.posts.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "defaultCell", for: indexPath)

        let tempPost = model.posts[indexPath.row]

        cell.textLabel?.text=tempPost.name
        
        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

class LOLTableViewCell:UITableViewCell{
    
}
