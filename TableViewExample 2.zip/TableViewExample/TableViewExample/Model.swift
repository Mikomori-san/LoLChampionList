//
//  Model.swift
//  TableViewExample
//
//  Created by user on 15.03.21.
//

import Foundation

class Model{
    var posts = [Post]()
    
}
