//
//  Post.swift
//  TableViewExample
//
//  Created by user on 15.03.21.
//

import Foundation

class Post {
    var armor : Int?
    var armorperlevel:Int?
    var attackdamage:Int?
    var attackdamageperlevel:Int?
    var attackrange:Int?
    var attackspeedoffset:Int?
    var attackspeedperlevel:Int?
    var big_image_url:String?
    var crit:Int?
    var critperlevel:Int?
    var hp:Int?
    var hpperlevel:Int?
    var hpregen:Int?
    var hpregenperlevel:Int?
    var id:Int?
    var image_url:String?
    var movespeed:Int?
    var mp:Int?
    var mpperlevel:Int?
    var mpregen:Int?
    var mpregenperlevel:Int?
    var name:String?
    var spellblock:Int?
    var spellblockperlevel:Int?
    }
