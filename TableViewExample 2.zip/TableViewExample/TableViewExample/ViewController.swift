//
//  ViewController.swift
//  TableViewExample
//
//  Created by user on 15.03.21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

